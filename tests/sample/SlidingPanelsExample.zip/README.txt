1) Sideload the app SlidingPanelsExample.zip
2) To run the tests, issue the following ECP command:
$ curl -d '' 'http://{Roku Device IP Address:8060/launch/dev?RunTests=true'
